# pycnc

[![Ready](http://img.shields.io/badge/Status-ready-669900.svg)](https://github.com/floatingpointstack)
[![Build Status](https://travis-ci.org/floatingpointstack/pycnc.svg)](https://travis-ci.org/floatingpointstack/pycnc)
[![Coverage Status](https://coveralls.io/repos/floatingpointstack/pycnc/badge.svg?branch=master&service=github)](https://coveralls.io/github/floatingpointstack/pycnc?branch=master)
[![GPL v2](http://img.shields.io/badge/license-GPL v2-blue.svg)](https://www.gnu.org/copyleft/gpl.html)
[![OS](http://img.shields.io/badge/OS-Windows Linux OSX-660099.svg)](https://www.python.org/downloads/)
[![Python 2.7 3.*](http://img.shields.io/badge/Python-2.7 3.*-ff3366.svg)](https://www.python.org/downloads/)

A set of 2.5D CNC Python routines to generate GCode for simple geometries machining on a 3 axis mill or router.

## Available GCode generators

To be completed ...


