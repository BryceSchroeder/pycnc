# Install

## from zip or tar

1. unzip dist/pycnc-1.0.zip (windows) or dist/untar pycnc-1.0.tar.gz (linux)
2. cd into new directory (where setup.py is located)
3. python setup.py install

## simple install

Copying gcode_generator.py to the same folder as your client scripts is also okay (and simpler) ....