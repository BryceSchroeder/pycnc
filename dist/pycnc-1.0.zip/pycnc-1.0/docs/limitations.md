# Limitations

## Geometry

pycnc is limited to simple 2.5D shapes. For complex 2D and 3D shapes, [Pycam](http://pycam.sourceforge.net/) is a good free alternative.