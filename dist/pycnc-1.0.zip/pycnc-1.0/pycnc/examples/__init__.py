#!/usr/bin/python
# coding: utf-8

r"""
"""
